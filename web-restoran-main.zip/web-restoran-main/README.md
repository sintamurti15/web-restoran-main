# BiFood
Website Pemesanan Makanan dan Minuman

## Cara Menjalankan
1. Export Database dan masukan ke database bifood_db
2. Jalankan Server
3. Akses URL "http://localhost/bifood/login.php"
4. Masukan Username dan Password (atau bisa dibuat akun baru) Admin -> username: bilyhakim, password: bily123 | User -> username: user, password: user
5. Jika admin, maka akan ke redirect ke halaman menu admin yang bisa mengedit data produk
6. Jika User, hanya bisa melakukan pembelian

## Gambar Pendukung
- Halaman Login
![image](https://user-images.githubusercontent.com/56821766/176750835-275c948b-0719-401b-8258-4bcd9e283050.png)
- Halaman Menu Admin
![image](https://user-images.githubusercontent.com/56821766/176805930-63bfdfe4-cfb4-403e-926e-1a2861ffd39a.png)
- Halaman Home
![image](https://user-images.githubusercontent.com/56821766/176819726-71086c97-0325-4a49-91a1-f30423e0ad5f.png)
![image](https://user-images.githubusercontent.com/56821766/176819834-19b5303c-dace-4ae1-bd00-ed2f4f9afeaf.png)
-Halaman Menu Pembeli
![image](https://user-images.githubusercontent.com/56821766/176820001-7ec29311-c1f2-4ee5-a901-b69da763c596.png)
- Halaman Pesanan Pembeli
![image](https://user-images.githubusercontent.com/56821766/176820090-2ddc5a8c-aefa-49d1-89a4-bc2baaed95e0.png)
- Halaman Edit Menu Admin
![image](https://user-images.githubusercontent.com/56821766/176820954-0f7c9ed5-3cc6-4f30-822d-c43197aa25c8.png)
- Halaman Tambah Menu
![image](https://user-images.githubusercontent.com/56821766/176821174-eab5ecb4-fad2-4369-a19b-17d361728f81.png)

